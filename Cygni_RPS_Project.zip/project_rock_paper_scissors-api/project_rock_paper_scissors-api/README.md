# Rock Paper Scissors API

A REST API to play Rock, Paper, Scissors.

## Node version 
node - v22.11.0

## Requirements 
   Node.js v22+ installed on your machine.
   NPM (comes with Node.js) for managing dependencies.

1. **Install dependencies**:
   ```bash
   - npm install
   - express: 4.21.1
   - joi: 17.13.3

1. **Technology stack**:
   Node.js: Backend runtime environment.
   Express.js: Framework for building the REST API.
   Joi: For request validation.
   Nodemon: For development (auto-reloading).


## Run the Application locally 

   ### Development Mode (with Nodemon)
   `npm run dev `

   ### Production Mode
   `npm start`

   ### Build mode ( Babel/Cli)
   `npm run build`

## Build with babel 

   ### Installing the package 
   `npm install --save-dev @babel/cli @babel/preset-env`

   ### Configure Babel
   Create a .babelsrc file in the root of your project.
      {
         "presets": ["@babel/preset-env"]
      } 

## Add a babel build project
   Update the "build" script in package.json

   "scripts": {
      "start": "node server.js",
      "dev": "nodemon server.js",
      "build": "babel src --out-dir dist"
   }



