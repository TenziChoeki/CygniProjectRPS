const express = require('express');
const router = express.Router();
const gameController = require('../controllers/gameController');

router.post('/games', gameController.createGame);
router.patch('/games/:id/join', gameController.joinGame);
router.patch('/games/:id/move', gameController.makeMove);
router.get('/games/:id', gameController.getGameStatus);

module.exports = router;
