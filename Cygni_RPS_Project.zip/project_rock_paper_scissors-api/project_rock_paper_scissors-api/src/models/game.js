const { determineWinner } = require('../utils/gameLogic');

class Game {
    constructor(id, player1) {
        this.id = id;
        this.player1 = player1;      // Player 1 is set at game creation
        this.player2 = null;         // Player 2 will be set once they join
        this.moves = { player1: null, player2: null };  // Moves start as null
        this.winner = null;          // Winner is determined after both moves
    }

    join(player2) {
        // Check if the game already has a second player
        if (this.player2) throw new Error('Game already has two players');
        this.player2 = player2;  // Set player2 when they join
    }

    makeMove(player, move) {
        // Check that the move is valid (rock, paper, or scissors)
        if (!['rock', 'paper', 'scissors'].includes(move)) throw new Error('Invalid move');

        // Set the move for the correct player
        if (player === this.player1) {
            this.moves.player1 = move;
        } else if (player === this.player2) {
            this.moves.player2 = move;
        } else {
            throw new Error('Player not found in this game');
        }

        // Check if both players have made moves
        if (this.moves.player1 && this.moves.player2) {
            this.winner = determineWinner(this.moves.player1, this.moves.player2);
        }
    }

    getStatus() {
        return {
            id: this.id,
            player1: this.player1,
            player2: this.player2,
            moves: this.moves,
            winner: this.winner,
        };
    }
}

module.exports = Game;
