const moves = ['rock', 'paper', 'scissors'];

const determineWinner = (move1, move2) => {
    if (move1 === move2) return 'tie';
    if (
        (move1 === 'rock' && move2 === 'scissors') ||
        (move1 === 'paper' && move2 === 'rock') ||
        (move1 === 'scissors' && move2 === 'paper')
    ) return 'player1';
    return 'player2';
};

module.exports = { moves, determineWinner };
