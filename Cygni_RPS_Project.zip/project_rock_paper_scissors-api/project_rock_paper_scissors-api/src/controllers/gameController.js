const Game = require('../models/game');
const { moves, determineWinner } = require('../utils/gameLogic');
const Joi = require('joi');

const games = new Map();  // In-memory store for games

// Schema for validating player creation/joining
const playerSchema = Joi.object({
    player: Joi.string().required()
});

// Schema for validating moves
const moveSchema = Joi.object({
    player: Joi.string().required(),
    move: Joi.string().valid('rock', 'paper', 'scissors').required()
});

// Endpoint to create a new game
exports.createGame = (req, res) => {
    const { error, value } = playerSchema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });

    const gameId = `game-${Date.now()}`;
    const game = new Game(gameId, value.player);
    games.set(gameId, game);
    res.status(201).json({ gameId });
};

// Endpoint for player 2 to join the game
exports.joinGame = (req, res) => {
    const game = games.get(req.params.id);
    if (!game) return res.status(404).json({ error: 'Game not found' });

    const { error, value } = playerSchema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });

    try {
        game.join(value.player);
        res.status(200).json({ message: 'Joined successfully' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Endpoint for players to make a move
exports.makeMove = (req, res) => {
    const game = games.get(req.params.id);
    if (!game) return res.status(404).json({ error: 'Game not found' });

    const { error, value } = moveSchema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });

    try {
        game.makeMove(value.player, value.move);
        res.status(200).json(game.getStatus());
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

// Endpoint to get the status of the game
exports.getGameStatus = (req, res) => {
    const game = games.get(req.params.id);
    if (!game) return res.status(404).json({ error: 'Game not found' });
    res.status(200).json(game.getStatus());
};
